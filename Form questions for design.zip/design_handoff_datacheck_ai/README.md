# Handoff: DataCheck AI — Control Center

## Overview
DataCheck AI is an AI-powered data engineering control center: it monitors pipelines (SAP → S3 → AWS Glue → Redshift → QuickSight, plus Snowflake/Databricks/BigQuery paths), runs source-to-target validation, tracks data quality/lineage/schema drift, raises incidents and alerts, tracks cloud cost, and lets an engineer ask an AI assistant to explain failures and generate fix code (SQL/PySpark). It targets a Data Engineer as primary user, with a companion mobile view for on-call monitoring.

## About the Design Files
The file in this bundle (`DataCheck AI.dc.html`) is a **design reference prototype**, built in an internal HTML component format (a single-file "Design Component" with inline styles and a small React-like logic class) — it is not production code and should not be copied into a real codebase as-is. Treat it as a fully-specified, interactive spec: exact copy, states, colors, and behavior are final; the implementation should be **recreated in the target stack** — per the original product brief, **Next.js (frontend) + FastAPI (backend) + PostgreSQL (database)** — using that stack's own component patterns, not by porting the HTML/JS directly.

To view it: open `DataCheck AI.dc.html` in any modern browser. It's fully interactive — sign in (any password), click through the dashboard, drill into the failing SAP Billing pipeline, click "Explain with AI," then "Apply fix & retry" to see the whole app heal (KPIs, incident, mobile health ring).

## Fidelity
**High-fidelity.** Colors, typography, spacing, copy, and interaction states are final and should be recreated pixel-for-pixel. Where the design shows placeholder/demo data (pipeline names, log lines, SQL), treat the **shape and fields** of that data as final — the actual values will come from real systems.

## Design system
Built on **Nocturne**, a dark, compact, low-chroma design system (Inter typeface, 8px base radius, single accent `#9184d9` used as outline/glow, never a flood fill). If the target codebase doesn't already have a design system, port Nocturne's tokens (see Design Tokens below) as CSS variables/Tailwind theme; if it does, map these roles onto the existing system rather than introducing a second one.

## Screens / Views
All screens share a fixed 214px left sidebar (logo, nav with badges, user footer) and a top bar (environment switcher: Production/UAT/Development, global search, Live AI toggle, mobile-preview toggle, alerts bell). Main content area is `overflow:auto`, padded 20px/22px.

1. **Login** — Split screen. Left: dark gradient brand panel with headline "Detect it. Explain it. Fix it.", 3 feature bullets, compliance footer (SOC 2, SSO/SCIM, region). Right: centered sign-in card — email/password fields, remember-me, primary "Sign in" button, divider, 3 SSO buttons (Google/Microsoft/SAML).

2. **Dashboard** — "Platform health" header + refresh/Ask-AI actions. Row of 10 KPI cards (grid, wraps responsively) showing pipeline counts, DQ score, incidents, cost, etc. — each clickable, routing to the relevant screen. "Critical path" card: 7-node horizontal stage chain (SAP CDS → OData → Fivetran → S3 → Glue → Redshift → QuickSight) with per-stage status icon/color/pulse animation on "running." Two-column lower section: "Needs attention" incident list (left, wider) and a right column stacking a 6-dimension data-quality score card (progress bars) and a 14-day cost sparkline (inline SVG).

3. **Pipelines** — Header + Filters/Export buttons. Status filter chips (All/Failed/Delayed/Running/Healthy) with live counts. Table: Pipeline (icon+name), Source→Destination, Status (colored dot+label), Last run, Next run, Records, Runtime, SLA, Owner. Rows open Pipeline Detail.

4. **Pipeline Detail** — Breadcrumb, title + status tag + env tag, action buttons (View logs, Validate, Create incident, Retry, **Explain with AI**). 6-metric strip (owner, schedule, last success, avg runtime, volume, SLA). 8-stage execution graph (per-stage icon/name/state/detail, pulsing on the failed stage). If failed: red-bordered error card with stack excerpt + affected records + business impact + Explain-with-AI CTA. Optional collapsible CloudWatch-style log panel (monospace, colored by level). Two-column footer: run-history table (8 runs, sparkline "vs avg" bar) and downstream-impact list (icon/name/state chips), linking to Lineage.

5. **Validation** — Header + New-run/Run-validation actions. Two side-by-side cards (Source: SAP connection fields; Target: Redshift connection fields), each showing row/column/profiled-at counts. Rule-selection grid (12 toggleable rule chips with cost hints) + in-scope column chips. Running state: progress bar + live step label. Done state: 5 summary KPI cards + results table (test, rule, source value, target value, delta, status, "Explain & fix" action on failing rows).

6. **Data Quality** — Grouping segmented control (Pipeline/Table/Domain/Date). Left card: overall score + 6-dimension bars. Right card: 30-day dual-line trend chart (overall vs. worst dimension) via inline SVG. Table of tables/domains with per-dimension scores + trend arrow; clicking a row opens a detail panel below with findings (rule/severity/detail) and a sample-rows table of the actual offending records, plus Validate/Explain actions.

7. **Data Lineage** — Table-lineage / Column-lineage toggle + search. Horizontal swimlane diagram (Source → Ingestion → Lake/Transform → Warehouse → Consumption, or the column-level equivalent) of clickable nodes, colored by health, with a focused/target node highlighted. Clicking a node updates a "Focus: X" breadcrumb. Below: two-column upstream/downstream dependency lists.

8. **Schema Changes** — Left: scrollable list of detected changes (table, severity, one-line summary, timestamp), selectable. Right: detail panel — previous vs. current column definitions side by side (monospace diff), AI-written "possible impact" paragraph, affected-assets list, and actions (Assess impact with AI, View lineage, Accept new version).

9. **Incidents** — Table of all incidents (id, pipeline, severity, status, env, detected time, owner, records), selectable rows. Detail panel below: title/severity/status, 4 border-accented fact cells, two-column root-cause/resolution and business-impact/timeline text, "Generate RCA with AI" button that reveals a five-whys + corrective-actions + detection-gap RCA document.

10. **Alerts** — List of alerts (icon, type tag, title, subtitle, timestamp, per-alert Acknowledge + Explain buttons) plus a right-hand "Active rules" summary card (condition, severity dot, notification channel icon).

11. **Cloud Costs** — 4 summary KPI cards (today/MTD/forecast/cost-per-TB). Cost-anomaly callout card with AI explanation CTA. Two-column: spend-by-service bar list and a per-pipeline cost table (today/MTD/unit cost/trend).

12. **AI Assistant + Code Generator** — Two-pane split. Left: chat thread (bubbles, live/scripted mode tag), quick-suggestion chips, input + send. Right: code generator — SQL/PySpark tab switch, template chip picker (10 templates each — dedup, null check, source-target compare, incremental, merge, hash compare, etc.), SQL dialect picker (7 dialects) when in SQL mode, generated code pane (monospace, copy button, "Run as validation" action).

13. **Connections** — Grouped by provider (AWS/GCP/Data platforms) grid of connection cards: icon, name, host/identifier, status dot, connected/degraded/available tag, last-sync time. "Add connection" primary action.

14. **Settings** — Users & roles table. Environments list (lock state per env) + AI settings (response mode, context sources, auto-RCA, default SQL dialect). Full alert-rules table (condition, severity, channels, scope, enabled state).

**Mobile companion** (rendered as a 344×~716px phone frame docked to the right of the web app, toggleable) — 5 tabs: Home (health ring, status counts, latest-issue card with 4 quick actions, latest alerts), Pipelines (compact list), Alerts (full list, ack-all), AI (same assistant, condensed), Profile (avatar, role, settings list). A push-notification banner can drop in from the top and is tappable to open the AI explain panel.

## Interactions & Behavior
- **Hero flow**: Dashboard KPI/stage-chain click → Pipeline Detail (SAP Billing, failed) → "Explain with AI" opens a 498px right-side drawer that shows a ~1.5s skeleton-loading state, then a 5–7 section AI root-cause analysis (summary, cause, affected component, affected records, recommended fix, preventive action) plus a generated Redshift SQL fix with a Copy button → drawer footer "Apply fix & retry" opens a confirmation dialog (restart point, business key, ETA, post-run check) → confirming shows a toast, transitions the pipeline to a "retrying" state for ~2.6s, then the entire app **heals**: stage graph turns green, KPIs update, the incident is marked resolved, downstream (agg_daily_revenue) unblocks, mobile health ring goes to 99%.
- **Live AI toggle** (top bar): when on, the Explain panel and chat call a real model (via a `window.claude.complete` bridge in the prototype) instead of returning scripted/canned text; a badge on the drawer and chat header shows "Live model" vs "Scripted."
- **Validation run**: clicking "Run validation" animates a progress bar over ~2s with rotating step labels, then reveals the results table; failing rows expose "Explain & fix," which reuses the same AI drawer pattern.
- **Toasts**: bottom-center, auto-dismiss ~3.4s, used for validation completion, retry submission/success, incident creation, RCA generation, alert acknowledgment.
- **Responsive grids**: KPI/metric card grids recompute column count from available width (sidebar + optional mobile-rail width subtracted) rather than a fixed count, so cards never overflow when the mobile rail is shown.
- All list/table rows, filter chips, and nav items are click-driven state changes with no page reloads (single-page app model).

## State Management
Route-level state: current screen (`route`), selected environment, selected pipeline id, mobile-tab id, and modal/drawer open flags (AI drawer, retry-confirm dialog, log panel, push banner). Cross-cutting: a single `healed` boolean flips pipeline/incident/KPI data across the whole app once the fix is "applied" — in production this should instead be driven by real pipeline-run state rather than a client flag. Validation has its own local run state machine: `setup → running (0–100%) → done`. Chat keeps a message list plus a busy flag. Alerts track individual + bulk acknowledgment. Data-quality, lineage, and schema screens each track a "selected item" index that drives their detail panel.

## Design Tokens
From Nocturne (`_ds/nocturne-.../styles.css`), plus semantic status colors added for this product:

- **Ground**: `--color-bg` #161826, `--color-text` #e9e9ed, surfaces via `--color-surface` / neutral ramp steps 700–900.
- **Accent**: #9184d9 (`--color-accent`), ramp steps 100–900, used as outline/glow only — never a flood fill.
- **Status colors** (defined in this build, OKLCH): success/healthy `oklch(0.74 0.13 155)`, failure `oklch(0.68 0.17 22)`, warning `oklch(0.80 0.13 85)`, running `oklch(0.72 0.12 245)`, idle/neutral `#75798c` — each with a ~13%-alpha tint variant for fills/badges.
- **Type**: Inter for heading and body (`--font-heading` / `--font-body`), base UI size 13px; monospace (JetBrains Mono) for all IDs, code, logs, and tabular numeric values.
- **Radius**: 8px base (`--radius-md` etc. from the token scale).
- **Spacing**: Nocturne's compact 0.7× density scale — component padding generally 10–16px, grid gaps 10px.
- **Elevation**: `.elev-sm` card shadow only; no heavy/stacked shadows.

## Assets
- Icons: Phosphor Icons (regular + fill sets), loaded via CDN stylesheet — swap for the target codebase's icon library, keeping the same glyph choices (shield-check, gear-six, sparkle, x-circle, warning-octagon, flow-arrow, etc.).
- Font: Inter (already in Nocturne) + JetBrains Mono (Google Fonts) for monospace contexts.
- No photographic or custom illustration assets are used.

## Files
- `DataCheck AI.dc.html` — the complete interactive design reference (all 13 screens + mobile companion + AI drawer + dialogs), self-contained.

## Suggested backend shape (from the original product brief)
Not implemented in the prototype (which uses static/mock data), but implied by the screens above — a starting point for the FastAPI/PostgreSQL side:

**Core tables**: `users` (role: data_engineer/eng_lead/administrator), `connections` (provider, type, host, status), `pipelines` (source/destination, schedule, owner, sla), `pipeline_runs` (status, started_at, records, runtime, logs_ref), `pipeline_stages` (per-run stage status), `validation_runs` + `validation_results` (rule, source_value, target_value, delta, status), `data_quality_scores` (table, dimension, score, measured_at), `schema_changes` (table, prev_definition, cur_definition, severity), `incidents` (pipeline_id, severity, status, root_cause, resolution), `alerts` (type, severity, title, acknowledged_at), `cost_records` (service, pipeline_id, date, amount).

**Key endpoints**: `GET /pipelines`, `GET /pipelines/{id}`, `POST /pipelines/{id}/retry`, `POST /pipelines/{id}/validate`, `GET /validation-runs/{id}`, `GET /data-quality`, `GET /lineage/{table}`, `GET /schema-changes`, `GET /incidents`, `POST /incidents/{id}/rca`, `GET /alerts`, `POST /alerts/{id}/acknowledge`, `GET /costs`, `POST /ai/explain` (pipeline/incident context → root-cause + generated code), `POST /ai/chat`, `GET /connections`.

This is a starting sketch, not a spec — the engineering team should size the real schema against actual data volumes and the actual SAP/Redshift/QuickSight (or chosen) integration.
